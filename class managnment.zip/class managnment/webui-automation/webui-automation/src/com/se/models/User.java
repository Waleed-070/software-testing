package com.se.models;

public class User {
    public String firstName;
    public String lastName;
    public String email;
    public String username;
    public String password;
    public String confirmPassword;
}
