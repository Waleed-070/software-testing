package com.se.utils;

public interface IDisplayableEnum {
    String getDisplayText();
}
