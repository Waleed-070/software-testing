package com.se.utils;

import com.se.config.Constants;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.yaml.snakeyaml.scanner.Constant;

import static com.se.utils.UtilsSet.clickOnElement;
import static com.se.utils.UtilsSet.waitUntilNotNullOrFalse;

public class NavigationUtil {
    @Step("Opening a subject base on {0}.")
    public static void openSubjectFromLearnMenu(String subName) {
        clickOnElement(By.linkText(subName));
    }

    public static void clickLearnButton() {
        UtilsSet.clickOnElement(Constants.learning.uplearn);


    }
    public static void subjectcollection() {
        UtilsSet.clickOnElement(Constants.learning.CS);

    }

    public static void selectsubject() {
        UtilsSet.clickOnElement(Constants.learning.Database);

    }

    public static void clickOnsubscribe() {
        UtilsSet.clickOnElement(Constants.learning.Subscribe);

    }

    public static void selectClass(){
        UtilsSet.clickOnElement(Constants.learning.ClassSelecting);

    }

    public static void ClassSubscribed(){
        UtilsSet.clickOnElement(Constants.learning.Subscribed);

    }

    public static void LectureBTN(){
        UtilsSet.clickOnElement(Constants.learning.Lecture);

    }

    public static void BookBTN(){
        UtilsSet.clickOnElement(Constants.learning.LoadBook);

    }

    public static void UnsubscribeingFOR(){
        UtilsSet.clickOnElement(Constants.learning.ForUnScb);
    }

    public static void StudentsStatus(){
        UtilsSet.clickOnElement(Constants.learning.StatusOfStudent);

    }

    public static void RequestForUnSubscribe(){
        UtilsSet.clickOnElement(Constants.learning.UnSubRequest);

    }



}

