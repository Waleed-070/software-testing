package com.se.tests.smoke;

import com.se.config.Constants;
import com.se.rolesbase.StudentLoginBase;
import com.se.utils.NavigationUtil;
import com.se.utils.UtilsSet;
import org.testng.Assert;
import org.testng.annotations.Test;

public class StudentAccountTest extends StudentLoginBase {

//1
    @Test
    public void authenticStudentIsLoggedIn(){

        System.out.println("A Student is now logged in");
    }

    @Test(dependsOnMethods = "authenticStudentIsLoggedIn")
    public void selectTheSubject(){

        System.out.println("Starting verifySoftwareTestingNUttonIsShowingCoursesList test");

        NavigationUtil.clickSoftware_TestingButton();

        System.out.println("Software Testing, button is clicked");
    }

    @Test(dependsOnMethods = "selectTheSubject")
    public void clickOnLectureBTN(){

        System.out.println("Starting verifyLectureButtonIsShowingCoursesList test");

        NavigationUtil.clickOnLectureButton();

        System.out.println("Lecture, button is clicked");
    }

    @Test(dependsOnMethods = "clickOnLectureBTN")
    public void clickLecturePerformance(){

        System.out.println("Starting verifyLectureButtonIsShowingCoursesList test");

        NavigationUtil.clickOnLecturePerformanceButton();

        System.out.println("Lecture Performance, button is clicked");
    }

    @Test(dependsOnMethods = "clickLecturePerformance")
    public void clickLectureTile(){

        System.out.println("Starting verifyLecturePerformanceButtonIsShowing test");

        NavigationUtil.clickOnLectureTitleButton();

        System.out.println("Lecture Performance, button is clicked");
        try{
            UtilsSet.waitForElementToBeVisible(Constants.learning.performance_inTab, 30);
            String performance = UtilsSet.findElement(Constants.learning.performance_inTab).getText();
            Assert.assertEquals(performance, "Performance", "Mismatch Performance  tab");
            System.out.println("--Performance Tab is visible with text in tab : " + performance);

            UtilsSet.waitForElementToBeVisible(Constants.learning.class_test, 30);
            String classtest = UtilsSet.findElement(Constants.learning.class_test).getText();
            Assert.assertEquals(classtest, "SP24-BSE-6A", "Mismatch class  ");
            System.out.println("--CLass is visiable in Performance Tab: " + classtest);

            UtilsSet.waitForElementToBeVisible(Constants.learning.percentage_inTab, 30);
            String percentage = UtilsSet.findElement(Constants.learning.percentage_inTab).getText();
            Assert.assertEquals(percentage, "76 %", "Mismatch Performance  tab");
            System.out.println("--Percentage Tab is visible with text in tab : " + performance);

            UtilsSet.waitForElementToBeVisible(Constants.learning.name_inTab, 30);
            String nameTest = UtilsSet.findElement(Constants.learning.name_inTab).getText();
            Assert.assertEquals(nameTest, "Fawad Iqbal", "Mismatch class  ");
            System.out.println("--Name is visiable in Performance Tab: " + nameTest);

            UtilsSet.waitForElementToBeVisible(Constants.learning.status_inTab, 30);
            String statusTest = UtilsSet.findElement(Constants.learning.status_inTab).getText();
            Assert.assertEquals(statusTest, "Lazy Learning", "Mismatch class  ");
            System.out.println("--Status is visiable in Performance Tab: " + nameTest);

        }catch(Exception e){
            System.out.println("exception is  : "+ e.getMessage());
        }
    }

    @Test(dependsOnMethods = "clickLectureTile")
    public void clickLectureTask(){

        System.out.println("Starting verifyLectureTAskButtonIsShowingCoursesList test");

        NavigationUtil.clickOnLectureTaskButton();

        System.out.println("Task, button is clicked");

        UtilsSet.waitForElementToBeVisible(Constants.learning.taskNo_inTab, 30);
        String taskNo = UtilsSet.findElement(Constants.learning.taskNo_inTab).getText();
        Assert.assertEquals(taskNo, "2", "Mismatch Performance  tab");
        System.out.println("--taskNo visible with text in tab : " + taskNo);

    }

    @Test(dependsOnMethods = "clickLectureTask")
    public void clickLectureTaskDetail(){

        System.out.println("Starting verifyLectureTaskDetailButtonIsShowing test");

        NavigationUtil.clickOnLectureTaskDetailButton();

        System.out.println("task detail, button is clicked");

        UtilsSet.waitForElementToBeVisible(Constants.learning.taskDetail_inTab, 30);
        String taskDeatil = UtilsSet.findElement(Constants.learning.taskDetail_inTab).getText();
        Assert.assertEquals(taskDeatil, "Details for - Writing Basic Test Cases", "Mismatch Performance  tab");
        System.out.println("--taskDetail visible with text in tab : " + taskDeatil);

        UtilsSet.waitForElementToBeVisible(Constants.learning.taskSubmission_inTab, 30);
        String taskSubmission = UtilsSet.findElement(Constants.learning.taskSubmission_inTab).getText();
        Assert.assertEquals(taskSubmission, "Due", "Mismatch Performance  tab");
        System.out.println("--taskSubmission visible with text in tab : " + taskSubmission);

        UtilsSet.waitForElementToBeVisible(Constants.learning.taskSubmissionTime_inTab, 30);
        String taskSubmissionTime = UtilsSet.findElement(Constants.learning.taskSubmissionTime_inTab).getText();
        Assert.assertEquals(taskSubmissionTime, "No Submission Time", "Mismatch Performance  tab");
        System.out.println("--taskSubmission time visible with text in tab : " + taskSubmissionTime);

    }
































//2
//    @Test(dependsOnMethods = "authenticStudentIsLoggedIn")
//
//    public void verifyLearnButtonIsShowingCourses() {
//
//        System.out.println("Starting verifyLearnButtonIsShowingCourses test");
//
//        NavigationUtil.clickLearnButton();
//
//        System.out.println("Learn, button is clicked");
//        try{
//            UtilsSet.waitForElementToBeVisible(Constants.learning.course_inTab, 30);
//            String courses = UtilsSet.findElement(Constants.learning.course_inTab).getText();
//
//            Assert.assertEquals(courses, "Courses", "Mismatch courses in tab");
//            System.out.println("--Course is visible with text in tab : " + courses);
//        }catch(Exception e){
//            System.out.println("exception is  : "+ e.getMessage());
//        }
//
//    }
////    3
//    @Test(dependsOnMethods = "verifyLearnButtonIsShowingCourses")
//
//    public void SubjectCollection() {
//
//        System.out.println("Starting verifyLearnButtonIsShowingCourses test");
//
//        NavigationUtil.subjectcollection();
//
//        System.out.println("Course(COMPUTER SCIENCE) button is clicked");
//
//        try{
//            UtilsSet.waitForElementToBeVisible(Constants.learning.collection_inTab, 30);
//            String collection = UtilsSet.findElement(Constants.learning.collection_inTab).getText();
////
//            Assert.assertEquals(collection, "Database Systems", "Mismatch courses in tab");
//            System.out.println("--database is visible with text in tab : " + collection);
//        }catch(Exception e){
//            System.out.println("exception is  : "+ e.getMessage());
//        }
//
//    }
////    4
//    @Test(dependsOnMethods = "SubjectCollection")
//    public void SelectSubject() {
//
//        System.out.println("Starting verifyDataBAseButtonIsShowingInComputerScience test");
//
//        NavigationUtil.selectsubject();
//
//        System.out.println("data base button is clicked");
//
//    }
////    5
//    @Test(dependsOnMethods = "SelectSubject")
//    public void SubscribeSubject() {
//
//        System.out.println("Starting verifySubscribeButtonIsShowing  test");
//
//        NavigationUtil.clickOnsubscribe();
//
//        System.out.println("Subscribe button is Selected");
//
//    }
////    6
//    @Test(dependsOnMethods = "SubscribeSubject")
//    public void classSelection() {
//
//        System.out.println("Starting verifyCheckBoxsIsShowingOfClassList test");
//
//        NavigationUtil.selectClass();
//
//        System.out.println("Check box is clicked");
//
//    }
////7
//    @Test(dependsOnMethods = "classSelection")
//    public void subscribedClass() {
//
//        System.out.println("Starting verifySubscribeButtonIsShowing test");
//
//        NavigationUtil.ClassSubscribed();
//
//        System.out.println("Subscribe button is clicked");
//
//    }
////    8
//    @Test(dependsOnMethods = "subscribedClass")
//    public void BtnForLecture() {
//
//        System.out.println("Starting verifyLectureButtonIsShowing test");
//
//        NavigationUtil.LectureBTN();
//
//        System.out.println("Lecture button is clicked");
//
//    }
////    9
//@Test(dependsOnMethods = "BtnForLecture")
//public void LoadLecture() {
//
//    System.out.println("Starting verifyBookButtonIsShowing test");
//
//    NavigationUtil.BookBTN();
//
//    System.out.println("Book is Selected");
//
//}
//
//@Test(dependsOnMethods = "LoadLecture")
//    public void SearchBar(){
//    System.out.println("Starting verifySearchButtonIsShowing test");
//
//    NavigationUtil.Searchbar();
//
//    System.out.println("Search Bar is clicked");
//}

//9
//    @Test(dependsOnMethods = "LoadLecture")
//    public void forUnSubscribe(){
//        System.out.println("Starting verifyUnSubscribeButtonIsShowing test");
//
//        NavigationUtil.UnsubscribeingFOR();
//
//        System.out.println("Subscribe button is clicked");
//    }
//10
//    @Test(dependsOnMethods = "forUnSubscribe")
//    public void studentStatus(){
//        System.out.println("Starting verifystudentStatusButtonIsShowing test");
//
//        NavigationUtil.StudentsStatus();
//
//        System.out.println("studentStatus button is clicked");
//    }
//11
//    @Test(dependsOnMethods = "studentStatus")
//    public void unSubscribingRequest(){
//        System.out.println("Starting verifyCancelSubscribeRequestButtonIsShowing test");
//
//        NavigationUtil.RequestForUnSubscribe();
//
//        System.out.println("Cancel Subscribe Request button is clicked");
//    }





}

