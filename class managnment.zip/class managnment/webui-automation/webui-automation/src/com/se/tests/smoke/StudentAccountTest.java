package com.se.tests.smoke;

import com.se.config.Constants;
import com.se.rolesbase.StudentLoginBase;
import com.se.utils.NavigationUtil;
import com.se.utils.UtilsSet;
import org.testng.Assert;
import org.testng.annotations.Test;

public class StudentAccountTest extends StudentLoginBase {

//1
    @Test
    public void authenticStudentIsLoggedIn(){

        System.out.println("A Student is now logged in");
    }
//2
    @Test(dependsOnMethods = "authenticStudentIsLoggedIn")

    public void verifyLearnButtonIsShowingCourses() {

        System.out.println("Starting verifyLearnButtonIsShowingCourses test");

        NavigationUtil.clickLearnButton();

        System.out.println("Learn, button is clicked");
        try{
            UtilsSet.waitForElementToBeVisible(Constants.learning.course_inTab, 30);
            String courses = UtilsSet.findElement(Constants.learning.course_inTab).getText();

            Assert.assertEquals(courses, "Courses", "Mismatch courses in tab");
            System.out.println("Course is visible with text in tab : " + courses);
        }catch(Exception e){
            System.out.println("exception is  : "+ e.getMessage());
        }

    }
//    3
    @Test(dependsOnMethods = "verifyLearnButtonIsShowingCourses")

    public void SubjectCollection() {

        System.out.println("Starting verifyLearnButtonIsShowingCourses test");

        NavigationUtil.subjectcollection();

        System.out.println("Course(COMPUTER SCIENCE) button is clicked");

        try{

        }catch(Exception e){
            System.out.println("exception is  : "+ e.getMessage());
        }

    }
//    4
    @Test(dependsOnMethods = "SubjectCollection")
    public void SelectSubject() {

        System.out.println("Starting verifyDataBAseButtonIsShowingInComputerScience test");

        NavigationUtil.selectsubject();

        System.out.println("data base button is clicked");

    }
//    5
    @Test(dependsOnMethods = "SelectSubject")
    public void SubscribeSubject() {

        System.out.println("Starting verifySubscribeButtonIsShowing  test");

        NavigationUtil.clickOnsubscribe();

        System.out.println("Subscribe button is Selected");

    }
//    6
    @Test(dependsOnMethods = "SubscribeSubject")
    public void classSelection() {

        System.out.println("Starting verifyCheckBoxsIsShowingOfClassList test");

        NavigationUtil.selectClass();

        System.out.println("Check box is clicked");

    }
//7
    @Test(dependsOnMethods = "classSelection")
    public void subscribedClass() {

        System.out.println("Starting verifySubscribeButtonIsShowing test");

        NavigationUtil.ClassSubscribed();

        System.out.println("Subscribe button is clicked");

    }
//    8
    @Test(dependsOnMethods = "subscribedClass")
    public void BtnForLecture() {

        System.out.println("Starting verifyLectureButtonIsShowing test");

        NavigationUtil.LectureBTN();

        System.out.println("Lecture button is clicked");

    }
//    9
@Test(dependsOnMethods = "BtnForLecture")
public void LoadLecture() {

    System.out.println("Starting verifyBookButtonIsShowing test");

    NavigationUtil.BookBTN();

    System.out.println("Book is Selected");

}

//9
    @Test(dependsOnMethods = "LoadLecture")
    public void forUnSubscribe(){
        System.out.println("Starting verifyUnSubscribeButtonIsShowing test");

        NavigationUtil.UnsubscribeingFOR();

        System.out.println("Subscribe button is clicked");
    }
//10
    @Test(dependsOnMethods = "forUnSubscribe")
    public void studentStatus(){
        System.out.println("Starting verifystudentStatusButtonIsShowing test");

        NavigationUtil.StudentsStatus();

        System.out.println("studentStatus button is clicked");
    }
//11
    @Test(dependsOnMethods = "studentStatus")
    public void unSubscribingRequest(){
        System.out.println("Starting verifyCancelSubscribeRequestButtonIsShowing test");

        NavigationUtil.RequestForUnSubscribe();

        System.out.println("Cancel Subscribe Request button is clicked");
    }



}

