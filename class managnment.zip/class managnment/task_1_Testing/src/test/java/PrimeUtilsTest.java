import static org.junit.Assert.*;
import org.junit.Test;

public class PrimeUtilsTest {

    @Test
    public void testIsPrime() {
        assertTrue(PrimeUtils.isPrime(5));  // TC1
        assertFalse(PrimeUtils.isPrime(4)); // TC2
        assertTrue(PrimeUtils.isPrime(2));  // TC3
        assertFalse(PrimeUtils.isPrime(1)); // TC4
        assertFalse(PrimeUtils.isPrime(0)); // TC5
        assertFalse(PrimeUtils.isPrime(-1));// TC6
        
    }
}
